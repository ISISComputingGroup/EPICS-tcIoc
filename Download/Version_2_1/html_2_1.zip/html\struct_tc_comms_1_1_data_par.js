var struct_tc_comms_1_1_data_par =
[
    [ "indexGroup", "struct_tc_comms_1_1_data_par.html#a6c536fd619ed0f54ffe565002fa926f2", null ],
    [ "indexOffset", "struct_tc_comms_1_1_data_par.html#a4df90b3861490eeba180aa7501f960de", null ],
    [ "length", "struct_tc_comms_1_1_data_par.html#a84bb0bfd14fa81aed4d6de1c5354ac9f", null ]
];