var struct_dev_tc_1_1dev_tc_def_waveform_in =
[
    [ "devTcDefWaveformIn", "group__devsup.html#gac9f9df4b75eef731986b55f65b36d286", null ]
];