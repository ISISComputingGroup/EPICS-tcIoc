var struct_epics_tpy_1_1macro__info =
[
    [ "macro_info", "struct_epics_tpy_1_1macro__info.html#a652e48484644a7525859cd872fa3dd69", null ],
    [ "name", "struct_epics_tpy_1_1macro__info.html#aad8f8be7d323fbc8ea393fb81d0fb6e4", null ],
    [ "ptype", "struct_epics_tpy_1_1macro__info.html#a2170d9c8003b919d836cf1a01e2098a3", null ],
    [ "readonly", "struct_epics_tpy_1_1macro__info.html#a0b09cbe209af1fa2265c607df232be7e", null ],
    [ "type_n", "struct_epics_tpy_1_1macro__info.html#a3cd4c324d56b30c906a8c66aae195b99", null ]
];