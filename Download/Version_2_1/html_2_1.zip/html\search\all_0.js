var searchData=
[
  ['_5f_5fdeclspec_0',['__declspec',['../ioc_main_8cpp.html#ad3b0205068812037ac792b91bb2669ef',1,'__declspec(dllimport) void stopTc(void):&#160;iocMain.cpp'],['../plc_base_8cpp.html#a99a77b63b57d56e8e81b9cd39b52b41c',1,'__declspec(dllexport) void stopTc(void):&#160;plcBase.cpp']]]
];
