var info_plc_8h =
[
    [ "info_dbrecord_list", "info_plc_8h.html#ga4e87a393ef90be666711b25d57941942", null ],
    [ "info_dbrecord_type", "info_plc_8h.html#ga124fd405a15153314421377fd96af742", null ],
    [ "info_update_method", "info_plc_8h.html#ga81dde292f04d8c83d47572ce5eadff20", null ],
    [ "update_enum", "info_plc_8h.html#ga7e65a84846b5ec8d971ec6166b020337", [
      [ "forever", "info_plc_8h.html#gga7e65a84846b5ec8d971ec6166b020337ad7af994f1f1ef8b5e3beb9f7fb139f57", null ],
      [ "once", "info_plc_8h.html#gga7e65a84846b5ec8d971ec6166b020337ae2eff6c2dafd909df8508f891b385d88", null ],
      [ "done", "info_plc_8h.html#gga7e65a84846b5ec8d971ec6166b020337a6b2ded51d81a4403d8a4bd25fa1e57ee", null ]
    ] ]
];