var struct_dev_tc_1_1dev_tc_def_in =
[
    [ "rec_type", "group__devsup.html#ga830172abcc24bb59878b6fbff75e236a", null ],
    [ "rec_type_ptr", "group__devsup.html#ga472d72ab96292872770358cc4f332510", null ],
    [ "devTcDefIn", "group__devsup.html#gab7551b45651ac6a7ccd7ec86f4e7e50e", null ]
];