var modules =
[
    [ "Device support for TwinCAT/ADS", "group__devsup.html", "group__devsup" ],
    [ "Device driver functions", "group__iocshfunc.html", "group__iocshfunc" ],
    [ "Info interface classes and functions", "group__infoplc.html", "group__infoplc" ],
    [ "TwinCAT tpy file parser", "group__parsetpyopc.html", "group__parsetpyopc" ],
    [ "XML tpy file constants", "group__parsetpyconstxml.html", "group__parsetpyconstxml" ],
    [ "Parser utility functions and classes", "group__parseutilities.html", "group__parseutilities" ],
    [ "OPC property constants", "group__parsetpyconstopcprop.html", "group__parsetpyconstopcprop" ],
    [ "String functions and classes", "group___stringcase.html", "group___stringcase" ],
    [ "TwinCAT read/write scanning", "group__tccommgroup.html", "group__tccommgroup" ],
    [ "EPICS utility functions and classes", "group__epicstpyutil.html", "group__epicstpyutil" ],
    [ "EPICS constants", "group__tpytoepicsconstmax.html", "group__tpytoepicsconstmax" ]
];