var class_tc_comms_1_1_ams_router_notification =
[
    [ "get_ads_build", "class_tc_comms_1_1_ams_router_notification.html#adce7a23f11655502a34ac69fd9233853", null ],
    [ "get_ads_revision", "class_tc_comms_1_1_ams_router_notification.html#a0d29269309f9635f83ec7acd87cd27d3", null ],
    [ "get_ads_version", "class_tc_comms_1_1_ams_router_notification.html#a610acfd062340e1b827571e5a4940adc", null ],
    [ "RouterCall", "class_tc_comms_1_1_ams_router_notification.html#a608761250ae9f2b61b41bb60d7543d42", null ],
    [ "ads_build", "class_tc_comms_1_1_ams_router_notification.html#a6b83a5fad345d25d83630e830c42c7a4", null ],
    [ "ads_revision", "class_tc_comms_1_1_ams_router_notification.html#a31a3e213cea4d2fd7c23438b5b0cede3", null ],
    [ "ads_version", "class_tc_comms_1_1_ams_router_notification.html#aa17bd1d85a3ec6d0c484db9b3ef44851", null ]
];