var class_dev_tc_1_1register__devsup =
[
    [ "link_func", "group__devsup.html#gac7d7faae1f7af1c4b5aae0f7d74b00f3", null ],
    [ "test_pattern", "group__devsup.html#ga49aeb470ba02a1392bf89722bd7b96d3", null ],
    [ "test_pattern_list", "group__devsup.html#gae21afb6fcd3e7afba2c93c21603c5baf", null ],
    [ "register_devsup", "group__devsup.html#ga83aca16f7e598d3b25b2f73f0ca490a0", null ],
    [ "register_devsup", "group__devsup.html#ga627b8424794433f741c27ea38bb1af7e", null ],
    [ "operator=", "group__devsup.html#ga9b42a850d158052ca3a0e71ebb5c3114", null ],
    [ "tp_list", "group__devsup.html#gad0aa43e4d1130be653acb9766b3689c2", null ]
];