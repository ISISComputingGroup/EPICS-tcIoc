var struct_dev_tc_1_1dev_tc_def_out =
[
    [ "rec_type", "group__devsup.html#gaff7f31a8c4ab69f19cc3f0bd673c7713", null ],
    [ "rec_type_ptr", "group__devsup.html#ga807e9733191352f93644ebe2253672b0", null ],
    [ "devTcDefOut", "group__devsup.html#ga24fe9d072e76d7861e21342916feb248", null ]
];