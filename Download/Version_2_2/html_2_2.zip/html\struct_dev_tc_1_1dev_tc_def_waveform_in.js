var struct_dev_tc_1_1dev_tc_def_waveform_in =
[
    [ "rec_type", "group__devsup.html#gad50541b8731fc7e6460cf5d4d1c32f4c", null ],
    [ "rec_type_ptr", "group__devsup.html#ga3eb706003bb6605e48c4fadd94be77f7", null ],
    [ "devTcDefWaveformIn", "group__devsup.html#gac9f9df4b75eef731986b55f65b36d286", null ]
];