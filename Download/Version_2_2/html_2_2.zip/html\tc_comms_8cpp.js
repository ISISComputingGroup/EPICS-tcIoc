var tc_comms_8cpp =
[
    [ "ADScallback", "tc_comms_8cpp.html#a5079ce723cfdd4046640898f223f680f", null ],
    [ "errorPrintf", "tc_comms_8cpp.html#af8dda3d39492fc09677815a0114dee01", null ],
    [ "RouterCall", "tc_comms_8cpp.html#a49ac075d02ae5a32e114cf57416c6725", null ],
    [ "SEC_TO_UNIX_EPOCH", "tc_comms_8cpp.html#a42e07b85a2906e92a3a8436e8969d988", null ],
    [ "WINDOWS_TICK", "tc_comms_8cpp.html#aa41b38b633697bd88ce0d293968ec736", null ]
];