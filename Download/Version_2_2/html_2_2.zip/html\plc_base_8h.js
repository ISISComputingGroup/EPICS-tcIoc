var plc_base_8h =
[
    [ "Interface", "classplc_1_1_interface.html", "classplc_1_1_interface" ],
    [ "DataValueTraits", "structplc_1_1_data_value_traits.html", "structplc_1_1_data_value_traits" ],
    [ "DataValueTypeDef", "structplc_1_1_data_value_type_def.html", "structplc_1_1_data_value_type_def" ],
    [ "DataValue", "classplc_1_1_data_value.html", "classplc_1_1_data_value" ],
    [ "BaseRecord", "classplc_1_1_base_record.html", "classplc_1_1_base_record" ],
    [ "BasePLC", "classplc_1_1_base_p_l_c.html", "classplc_1_1_base_p_l_c" ],
    [ "System", "classplc_1_1_system.html", "classplc_1_1_system" ],
    [ "BasePLCList", "plc_base_8h.html#a75f1fde21307ab6681ef0817120feff5", null ],
    [ "BasePLCPtr", "plc_base_8h.html#a79963168c698aaa1e126b53df03057a9", null ],
    [ "BaseRecordList", "plc_base_8h.html#a2fc03b7d47c20f8ef17b9aece13d5aba", null ],
    [ "BaseRecordPtr", "plc_base_8h.html#a104920ce8a9e80eedcd53160e428f1f6", null ],
    [ "InterfacePtr", "plc_base_8h.html#ae3a11e33a9b83e279ca3ddea84af00c5", null ],
    [ "access_rights_enum", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51", [
      [ "read_only", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51abefe72871b2de8f4f0e20108517e31fe", null ],
      [ "write_only", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51a2629564984b808cf7e6cfc61a0286d69", null ],
      [ "read_write", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51a06ad287ea83b37a6f9db3d8d10d72c8f", null ]
    ] ],
    [ "data_type_enum", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254e", [
      [ "dtInvalid", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea891a63f1a4ce49c1a142de5f26d10be8", null ],
      [ "dtBool", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eab537c5e5f40eb94f7cc0bf76ea35a85b", null ],
      [ "dtInt8", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eae4f58ea6dfd70e3bb4c8f22aa88dff28", null ],
      [ "dtUInt8", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaf3c60620ef4d0f17276e29d0e44bbfc8", null ],
      [ "dtInt16", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea0b1a08ac8bc2e8320d6ad092a9d8f00e", null ],
      [ "dtUInt16", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaf0ca039018a00a4890ea22ee5efb701c", null ],
      [ "dtInt32", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ead74732f230a08ad689c43b35d905864a", null ],
      [ "dtUInt32", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eae882773ae352ed2214839937bc5c777c", null ],
      [ "dtInt64", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eac65eac5fbe83f3f40a1d79a24ad498ad", null ],
      [ "dtUInt64", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea96dc72995a6b8ff35b8fbdec8b9d2432", null ],
      [ "dtFloat", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eac4235ad461f262a7bdcaf98cc3ce7657", null ],
      [ "dtDouble", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea3ae77aa57967da768c33526a09ecec31", null ],
      [ "dtString", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eafa4ba368f7ca13fcbf69fc67af8cb115", null ],
      [ "dtWString", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ead3529b473ac1db18ad11b71f00b5e773", null ],
      [ "dtBinary", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eada01155bb4f4af65a06f9a1d1890582a", null ]
    ] ]
];