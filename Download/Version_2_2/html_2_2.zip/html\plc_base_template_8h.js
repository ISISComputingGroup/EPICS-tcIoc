var plc_base_template_8h =
[
    [ "reset_and_read", "plc_base_template_8h.html#a3582643b4f0519956c874bf11d9165ea", null ],
    [ "reset_and_read", "plc_base_template_8h.html#a426c6523f148cccc1aa455a95c267592", null ],
    [ "write_and_test", "plc_base_template_8h.html#aff445905fa231d720a15611acdde4c1b", null ],
    [ "write_and_test", "plc_base_template_8h.html#acd19a70a801de633eedf0458a25ff1c7", null ]
];