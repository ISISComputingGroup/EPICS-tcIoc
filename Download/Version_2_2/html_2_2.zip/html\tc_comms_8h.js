var tc_comms_8h =
[
    [ "default_multiple", "tc_comms_8h.html#ga0f3847ffad024aee42fb10647e2b8928", null ],
    [ "default_scanrate", "tc_comms_8h.html#ga2c4be1dfb3f0d1df8ddeaa04d158ae9f", null ],
    [ "MAX_REL_GAP", "tc_comms_8h.html#gade9acaf2567a544b55c47b5d7111e100", null ],
    [ "MAX_REQ_SIZE", "tc_comms_8h.html#gade6609bc2d9a0b0a7c9c538d4774b69e", null ],
    [ "MAX_SINGLE_GAP_SIZE", "tc_comms_8h.html#ga72ce62bb8d14014dfdb2de763e50b0ce", null ],
    [ "maximum_multiple", "tc_comms_8h.html#ga37f4bd1fced818206e595245d070d140", null ],
    [ "maximum_scanrate", "tc_comms_8h.html#ga7f084ead45e69b24507dcda017180967", null ],
    [ "MIN_REL_GAP_SIZE", "tc_comms_8h.html#gadc6e4fd89845467cd3dfa0a11c315f90", null ],
    [ "minimum_multiple", "tc_comms_8h.html#gabb2b31118e005957293e1c19c455fec1", null ],
    [ "minimum_scanrate", "tc_comms_8h.html#ga14768d7e4f6afa8af978795bef05ad67", null ]
];