var info_plc_8cpp =
[
    [ "SEC_TO_UNIX_EPOCH", "info_plc_8cpp.html#a1d5d7a06ec24c7e9169a39b9d72554b7", null ],
    [ "WINDOWS_TICK", "info_plc_8cpp.html#a269ad2e4b7355b662c5eed395a1ce1aa", null ]
];