var namespaceplc =
[
    [ "BasePLC", "classplc_1_1_base_p_l_c.html", "classplc_1_1_base_p_l_c" ],
    [ "BaseRecord", "classplc_1_1_base_record.html", "classplc_1_1_base_record" ],
    [ "DataValue", "classplc_1_1_data_value.html", "classplc_1_1_data_value" ],
    [ "DataValueTraits", "structplc_1_1_data_value_traits.html", "structplc_1_1_data_value_traits" ],
    [ "DataValueTypeDef", "structplc_1_1_data_value_type_def.html", "structplc_1_1_data_value_type_def" ],
    [ "Interface", "classplc_1_1_interface.html", "classplc_1_1_interface" ],
    [ "scanner_thread_args", "structplc_1_1scanner__thread__args.html", "structplc_1_1scanner__thread__args" ],
    [ "System", "classplc_1_1_system.html", "classplc_1_1_system" ]
];