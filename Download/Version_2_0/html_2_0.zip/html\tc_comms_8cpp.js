var tc_comms_8cpp =
[
    [ "_CRT_SECURE_NO_WARNINGS", "tc_comms_8cpp.html#af08ec37a8c99d747fb60fa15bc28678b", null ],
    [ "ADScallback", "tc_comms_8cpp.html#a5079ce723cfdd4046640898f223f680f", null ],
    [ "errorPrintf", "tc_comms_8cpp.html#af8dda3d39492fc09677815a0114dee01", null ],
    [ "RouterCall", "tc_comms_8cpp.html#a49ac075d02ae5a32e114cf57416c6725", null ]
];