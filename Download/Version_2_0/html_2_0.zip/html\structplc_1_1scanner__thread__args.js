var structplc_1_1scanner__thread__args =
[
    [ "plc", "structplc_1_1scanner__thread__args.html#af11ecae84f35afef946690ccccace042", null ],
    [ "scanner", "structplc_1_1scanner__thread__args.html#a6f354f69904f5ba9119f914457a561d7", null ],
    [ "scanperiod", "structplc_1_1scanner__thread__args.html#a461080d34cdbbf3de3602d555b006d29", null ]
];