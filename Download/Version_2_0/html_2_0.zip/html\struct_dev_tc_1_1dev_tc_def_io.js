var struct_dev_tc_1_1dev_tc_def_io =
[
    [ "rec_type", "group__devsup.html#ga5440f399e5d73a2c738596bc30eb17bc", null ],
    [ "rec_type_ptr", "group__devsup.html#ga668caa8884f890523c5a0dd29308fba4", null ],
    [ "devTcDefIo", "group__devsup.html#ga99c37eb0760ed76057d3329e744f4c4c", null ],
    [ "get_ioint_info_fn", "group__devsup.html#gab225c9425f25ffdbbef4310df6ce60ea", null ],
    [ "init_fn", "group__devsup.html#gad8fad3a920d401377b85def501bc7a3e", null ],
    [ "init_record_fn", "group__devsup.html#ga7d14e36e2174b6659d6271aeaa548f1e", null ],
    [ "io_fn", "group__devsup.html#gad4ebd5e1e52d0a110a2ec309eaf1c84a", null ],
    [ "number", "group__devsup.html#gad97f59a982d7bb5504a7ea0659482a43", null ],
    [ "report_fn", "group__devsup.html#ga12072a49ed2934de351dced652b58f86", null ],
    [ "special_linconv_fn", "group__devsup.html#ga1cc7eff33b76d330834943898b9178ac", null ]
];