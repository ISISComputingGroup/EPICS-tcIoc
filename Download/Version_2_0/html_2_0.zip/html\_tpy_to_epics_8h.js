var _tpy_to_epics_8h =
[
    [ "filename_set", "_tpy_to_epics_8h.html#ga3099c8a64e317e92557fe0249d4bc1f0", null ],
    [ "macro_list", "_tpy_to_epics_8h.html#ga69ebf23f1f095b54ce5f6954b1bf57a3", null ],
    [ "macro_stack", "_tpy_to_epics_8h.html#gaf994ebbaba8cb9b2065da9b404d72465", null ],
    [ "case_type", "_tpy_to_epics_8h.html#gaaf8df5b0192eef05c44e69139caaa7c7", [
      [ "preserve_case", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7a77fe23174e524bf4bd060248b2905533", null ],
      [ "upper_case", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7a98be1cce5f74f6d8d935dad1d5f7019e", null ],
      [ "lower_case", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7a4a90896787a73c5dabfa9549edc2e01f", null ]
    ] ],
    [ "device_support_type", "_tpy_to_epics_8h.html#ga9e59f965d3622fac3bc7d002a65dbdfd", [
      [ "device_support_opc_name", "_tpy_to_epics_8h.html#gga9e59f965d3622fac3bc7d002a65dbdfda47b5f9ff7d50e0e073cc8a1e29aa46e8", null ],
      [ "device_support_tc_name", "_tpy_to_epics_8h.html#gga9e59f965d3622fac3bc7d002a65dbdfdaae6e0a6dc5fecb520258d486642f7858", null ]
    ] ],
    [ "io_filestat", "_tpy_to_epics_8h.html#gaf411f410b43a71464024d95361c0166e", [
      [ "closed", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166ea349e686330723975502e9ef4f939a5ac", null ],
      [ "read", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166eaecae13117d6f0584c25a9da6c8f8415e", null ],
      [ "write", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166eaefb2a684e4afb7d55e6147fbe5a332ee", null ]
    ] ],
    [ "listing_type", "_tpy_to_epics_8h.html#gabed2590b28bc6043bf853812ff22277a", [
      [ "listing_standard", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aa3bd475e1b0f587d74b55eae23581ee92", null ],
      [ "listing_autoburt", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aa6f334705f5c352f3bd1ec5da5371e7c2", null ],
      [ "listing_daqini", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aa374e58bc3759b6af8c8bd2251e998934", null ]
    ] ],
    [ "macrofile_type", "_tpy_to_epics_8h.html#ga6c3eb4941fce47e4c387276703678269", [
      [ "all", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269aa181a603769c1f98ad927e7367c7aa51", null ],
      [ "fields", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269ad05b6ed7d2345020440df396d6da7f73", null ],
      [ "errors", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269a07213a0161f52846ab198be103b5ab43", null ]
    ] ],
    [ "tc_epics_conv", "_tpy_to_epics_8h.html#gada9a1bcaaea5adbfe965e4978032aa82", [
      [ "no_conversion", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a8b002459d1cf8d0de84123a3c042b091", null ],
      [ "no_dot", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a1955c9845a94565e8e4dfcbf423b996c", null ],
      [ "ligo_std", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a8395b375f546f080157259811d76e3d9", null ],
      [ "ligo_vac", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a85fb5cbd6895bc490f35b35faac91c85", null ]
    ] ]
];