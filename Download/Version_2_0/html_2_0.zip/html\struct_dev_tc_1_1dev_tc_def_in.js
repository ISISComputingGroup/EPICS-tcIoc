var struct_dev_tc_1_1dev_tc_def_in =
[
    [ "devTcDefIn", "group__devsup.html#gab7551b45651ac6a7ccd7ec86f4e7e50e", null ]
];