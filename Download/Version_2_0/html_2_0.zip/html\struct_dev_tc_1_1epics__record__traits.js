var struct_dev_tc_1_1epics__record__traits =
[
    [ "value_type", "group__devsup.html#ga3686eb4b8989bc438f2cc3a47f2d748c", null ]
];