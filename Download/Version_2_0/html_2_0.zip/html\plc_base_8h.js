var plc_base_8h =
[
    [ "Interface", "classplc_1_1_interface.html", "classplc_1_1_interface" ],
    [ "DataValueTraits", "structplc_1_1_data_value_traits.html", "structplc_1_1_data_value_traits" ],
    [ "DataValueTypeDef", "structplc_1_1_data_value_type_def.html", "structplc_1_1_data_value_type_def" ],
    [ "DataValue", "classplc_1_1_data_value.html", "classplc_1_1_data_value" ],
    [ "BaseRecord", "classplc_1_1_base_record.html", "classplc_1_1_base_record" ],
    [ "BasePLC", "classplc_1_1_base_p_l_c.html", "classplc_1_1_base_p_l_c" ],
    [ "System", "classplc_1_1_system.html", "classplc_1_1_system" ],
    [ "BasePLCList", "plc_base_8h.html#a75f1fde21307ab6681ef0817120feff5", null ],
    [ "BasePLCPtr", "plc_base_8h.html#a79963168c698aaa1e126b53df03057a9", null ],
    [ "BaseRecordList", "plc_base_8h.html#a2fc03b7d47c20f8ef17b9aece13d5aba", null ],
    [ "BaseRecordPtr", "plc_base_8h.html#a104920ce8a9e80eedcd53160e428f1f6", null ],
    [ "InterfacePtr", "plc_base_8h.html#ae3a11e33a9b83e279ca3ddea84af00c5", null ],
    [ "access_rights_enum", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51", [
      [ "read_only", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51a109c8a6edae1c9a1f526d524f5b42e16", null ],
      [ "write_only", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51af1e66343b31bbcddf26fee7b9272256c", null ],
      [ "read_write", "plc_base_8h.html#a33ecacfe0082b3121cd0fef60ab61e51a681416576104de1c777ad4037b1af232", null ]
    ] ],
    [ "data_type_enum", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254e", [
      [ "dtInvalid", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea74851ea95ed87ea18fbd8eb10a70256a", null ],
      [ "dtBool", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea0f20597efb1457425b1c70bb4e1c0284", null ],
      [ "dtInt8", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaf6882b1c53dedc0fa23c45455dc3684f", null ],
      [ "dtUInt8", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea50be481e8d7ab87ac5b9df0027d33bfd", null ],
      [ "dtInt16", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eac4506ffc23c2f3a1c3449c4bbde9e3ad", null ],
      [ "dtUInt16", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea0655de05aa6e11c7d7735e2937b73ce2", null ],
      [ "dtInt32", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea02c29d6a1d028199fa89ac72385d63a6", null ],
      [ "dtUInt32", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea1da4a8737531f31a0e88b2ea447795e4", null ],
      [ "dtInt64", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaf3b99f59934c4d894963bbcbb6be5190", null ],
      [ "dtUInt64", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eae346c029df87ba7a5acf26cc8256db52", null ],
      [ "dtFloat", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaf07923442ab56172b75eebaf3ece2624", null ],
      [ "dtDouble", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea9520b355c7a041ce889e3293aa58ae3c", null ],
      [ "dtString", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254eaecc054a3896aa34f8c7ee9ebeec62100", null ],
      [ "dtWString", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea963491ee47d24fa04b77f1b0d4f63e88", null ],
      [ "dtBinary", "plc_base_8h.html#aa1571065bf28d8e3b07395df1f65254ea1bc6f1a13dfb6b1d6ae9215ea4bad8ea", null ]
    ] ]
];