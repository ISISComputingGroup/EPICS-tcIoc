var class_info_plc_1_1process__arg__info =
[
    [ "process_arg_info", "class_info_plc_1_1process__arg__info.html#a7f91717ee9a97f2458d6053579505413", null ],
    [ "get_full", "class_info_plc_1_1process__arg__info.html#a6fc7224bd7826cdeafa09aa624f0c68c", null ],
    [ "tcplc_addr", "class_info_plc_1_1process__arg__info.html#a9caa0213eb47c90966fd8ba31ed5b07f", null ]
];