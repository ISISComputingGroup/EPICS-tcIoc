#pragma once
 
/// True, if there are modifications to the local working copy, false otherwise
const bool 			svn_local_modifications = false;
/// Highest committed revision number in the working copy
const int 			svn_revision = 4669;
/// Current system date &amp; time     
const char* const 	svn_time_now = "2019/06/25 17:14:11";
/// Revision number if fully committed, 0 otherwise
const int			svn_revision_committed = 4669;
