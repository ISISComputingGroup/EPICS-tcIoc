#pragma once
 
/// True, if there are modifications to the local working copy, false otherwise
constexpr bool 		svn_local_modifications = false;
/// Highest committed revision number in the working copy
constexpr int 		svn_revision = 5719;
/// Current system date &amp; time     
const char* const 	svn_time_now = "2022/02/24 09:04:40";
/// Revision number if fully committed, 0 otherwise
constexpr int		svn_revision_committed = 5719;
