var info_plc_8cpp =
[
    [ "SEC_TO_UNIX_EPOCH", "info_plc_8cpp.html#aa080d54ea8ee8248e6260bba1574d0c1", null ],
    [ "WINDOWS_TICK", "info_plc_8cpp.html#a90f550350724018d38bff68dc1e81162", null ]
];