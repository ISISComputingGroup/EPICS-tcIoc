var struct_dev_tc_1_1epics__record__traits =
[
    [ "traits_type", "group__devsup.html#gae7f21dd530953d7ac453251b77ccb50c", null ],
    [ "traits_type_ptr", "group__devsup.html#ga9bd1c7b2bc6b1527fb67108bab4d7954", null ],
    [ "value_type", "group__devsup.html#ga24ed3167c984c9808ee7ebb3765f9fd9", null ]
];