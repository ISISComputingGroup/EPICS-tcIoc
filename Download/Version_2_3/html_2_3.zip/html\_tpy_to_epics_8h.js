var _tpy_to_epics_8h =
[
    [ "filename_set", "_tpy_to_epics_8h.html#gaac8470213f95c03eea6cc7b30ccbf1d3", null ],
    [ "macro_list", "_tpy_to_epics_8h.html#gaa132f7e2b10501e32cbfc6262ce274ce", null ],
    [ "macro_stack", "_tpy_to_epics_8h.html#gaa056d1a99e7bad5f0b23602184e53b58", null ],
    [ "case_type", "_tpy_to_epics_8h.html#gaaf8df5b0192eef05c44e69139caaa7c7", [
      [ "preserve", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7aec4875cf2d241556a0965f7237864693", null ],
      [ "upper", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7a0122b4c2c01ee1c698ecc309d2b8eb5a", null ],
      [ "lower", "_tpy_to_epics_8h.html#ggaaf8df5b0192eef05c44e69139caaa7c7a81e073b428b50247daba38531dcf412a", null ]
    ] ],
    [ "device_support_type", "_tpy_to_epics_8h.html#ga9e59f965d3622fac3bc7d002a65dbdfd", [
      [ "opc_name", "_tpy_to_epics_8h.html#gga9e59f965d3622fac3bc7d002a65dbdfda67162c9f2378b47b1bc84ddb7e98cc9b", null ],
      [ "tc_name", "_tpy_to_epics_8h.html#gga9e59f965d3622fac3bc7d002a65dbdfda3d0be1468f636cfd695e5978b1b0f329", null ]
    ] ],
    [ "int_support_type", "_tpy_to_epics_8h.html#gac9e6ff90fca78411c62ec85ef9fde3d4", [
      [ "int_32", "_tpy_to_epics_8h.html#ggac9e6ff90fca78411c62ec85ef9fde3d4adc024be4047efc16a2573eafdf2bacea", null ],
      [ "int_64", "_tpy_to_epics_8h.html#ggac9e6ff90fca78411c62ec85ef9fde3d4a72df6a2f7732189957ee9ff9c3516d16", null ],
      [ "int_auto", "_tpy_to_epics_8h.html#ggac9e6ff90fca78411c62ec85ef9fde3d4a2b99cc573b6f6f97c667690d976b3f8a", null ]
    ] ],
    [ "io_filestat", "_tpy_to_epics_8h.html#gaf411f410b43a71464024d95361c0166e", [
      [ "closed", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166ea349e686330723975502e9ef4f939a5ac", null ],
      [ "read", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166eaecae13117d6f0584c25a9da6c8f8415e", null ],
      [ "write", "_tpy_to_epics_8h.html#ggaf411f410b43a71464024d95361c0166eaefb2a684e4afb7d55e6147fbe5a332ee", null ]
    ] ],
    [ "listing_type", "_tpy_to_epics_8h.html#gabed2590b28bc6043bf853812ff22277a", [
      [ "standard", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aac00f0c4675b91fb8b918e4079a0b1bac", null ],
      [ "autoburt", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aa4a9ed57b0caf58ca0058b9244e140806", null ],
      [ "daqini", "_tpy_to_epics_8h.html#ggabed2590b28bc6043bf853812ff22277aa0c781ff23b892596d7551d70b1c61b87", null ]
    ] ],
    [ "macrofile_type", "_tpy_to_epics_8h.html#ga6c3eb4941fce47e4c387276703678269", [
      [ "all", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269aa181a603769c1f98ad927e7367c7aa51", null ],
      [ "fields", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269ad05b6ed7d2345020440df396d6da7f73", null ],
      [ "errors", "_tpy_to_epics_8h.html#gga6c3eb4941fce47e4c387276703678269a07213a0161f52846ab198be103b5ab43", null ]
    ] ],
    [ "string_support_type", "_tpy_to_epics_8h.html#ga5c359bd68ddc5009fa3ec1fe44ebd4ea", [
      [ "short_string", "_tpy_to_epics_8h.html#gga5c359bd68ddc5009fa3ec1fe44ebd4eaae08ba29f56785332d9a97653dcc29443", null ],
      [ "long_string", "_tpy_to_epics_8h.html#gga5c359bd68ddc5009fa3ec1fe44ebd4eaad1d7fda9797d3aa79f58f17a343d96c4", null ],
      [ "vary_string", "_tpy_to_epics_8h.html#gga5c359bd68ddc5009fa3ec1fe44ebd4eaa51f4f458057484b906f46d59309bfa47", null ]
    ] ],
    [ "tc_epics_conv", "_tpy_to_epics_8h.html#gada9a1bcaaea5adbfe965e4978032aa82", [
      [ "no_conversion", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a18b56109b20f04b56ea224fe8b52de3d", null ],
      [ "no_dot", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a40545aa79868bd4c8b2108589a7d0fa2", null ],
      [ "ligo_std", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82a184ffc6b42949632e34750b06f8d7579", null ],
      [ "ligo_vac", "_tpy_to_epics_8h.html#ggada9a1bcaaea5adbfe965e4978032aa82aad2b1911f921b820b25ef14be3456254", null ]
    ] ]
];