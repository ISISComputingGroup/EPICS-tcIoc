var tc_comms_8cpp =
[
    [ "ADScallback", "tc_comms_8cpp.html#a5079ce723cfdd4046640898f223f680f", null ],
    [ "errorPrintf", "tc_comms_8cpp.html#a56f3bfc1a9637288383b0b16d2d7264d", null ],
    [ "RouterCall", "tc_comms_8cpp.html#a49ac075d02ae5a32e114cf57416c6725", null ],
    [ "SEC_TO_UNIX_EPOCH", "tc_comms_8cpp.html#ad8554f1d67c7af3ffb2c7275f5b2d1ec", null ],
    [ "WINDOWS_TICK", "tc_comms_8cpp.html#a248604fc0ca00ab2f2991f89cb47f63b", null ]
];