var stringcase_8h =
[
    [ "stringcase", "stringcase_8h.html#ga77c6fe7011644a24e51ff69f826d31ed", null ],
    [ "wstringcase", "stringcase_8h.html#ga6b104fdb2e3d3e8e1d0ce6179253eadf", null ],
    [ "split_string", "stringcase_8h.html#ga4f8a1d97344f1590f3ac2294816ae590", null ],
    [ "strncasecmp", "stringcase_8h.html#ga9a70e982efe8919ff13d1f8cec7fa5d7", null ],
    [ "trim_space", "stringcase_8h.html#gad27c28bbbdd94fd41d5b79eaea6b744a", null ],
    [ "trim_space", "stringcase_8h.html#ga9c5d8da955f5fa88b6a01d81c4bc4fbc", null ],
    [ "wcsncasewcmp", "stringcase_8h.html#gab1c75f9c7f77167c48f4475ec50302d9", null ]
];