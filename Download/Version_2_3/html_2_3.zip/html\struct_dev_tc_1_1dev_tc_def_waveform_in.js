var struct_dev_tc_1_1dev_tc_def_waveform_in =
[
    [ "rec_type", "group__devsup.html#ga7ef4b83218c0b2964e22e0d8020f94e2", null ],
    [ "rec_type_ptr", "group__devsup.html#ga6be32b583572ac447d8bc5a1680bb95a", null ],
    [ "devTcDefWaveformIn", "group__devsup.html#ga329a3d60bbdca4022333f38de7c6d977", null ]
];