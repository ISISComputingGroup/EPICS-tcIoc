var tc_comms_8h =
[
    [ "default_multiple", "tc_comms_8h.html#gac8311601fd66c955c2eeb1aadd5b4de0", null ],
    [ "default_scanrate", "tc_comms_8h.html#ga946f215005820e904c68b0ee4f853a5f", null ],
    [ "MAX_REL_GAP", "tc_comms_8h.html#ga19271df9f3d860cb3fbd4662c2fae8a1", null ],
    [ "MAX_REQ_SIZE", "tc_comms_8h.html#gaf4121e57fb92f54f4a21e5ef9b25379e", null ],
    [ "MAX_SINGLE_GAP_SIZE", "tc_comms_8h.html#ga9d5adc5b5bad016d64703408f4a2e825", null ],
    [ "maximum_multiple", "tc_comms_8h.html#ga96fd495c658f8fef60707de40c6eca33", null ],
    [ "maximum_scanrate", "tc_comms_8h.html#ga66ff0d2940dd7ab037891e81a623b063", null ],
    [ "MIN_REL_GAP_SIZE", "tc_comms_8h.html#gacabdd78a5c55d1cb4500fb7c48b7feea", null ],
    [ "minimum_multiple", "tc_comms_8h.html#gad8ce47018f9e2ef14a2c37f1e30defa9", null ],
    [ "minimum_scanrate", "tc_comms_8h.html#ga35a65c104665082cd3dbae27c317a495", null ]
];