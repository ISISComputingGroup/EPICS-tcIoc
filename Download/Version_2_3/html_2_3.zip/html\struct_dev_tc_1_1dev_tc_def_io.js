var struct_dev_tc_1_1dev_tc_def_io =
[
    [ "get_ioint_info_type", "group__devsup.html#gabc1d25ccdc5cbd76a3ff961c2444d95c", null ],
    [ "init_record_type", "group__devsup.html#gaf4bb6e0fa6a29ca69c2fa3a99a149117", null ],
    [ "init_type", "group__devsup.html#ga7cf1c1c03694d0622c4f319f4372817a", null ],
    [ "io_type", "group__devsup.html#gada4284b44e8ed4acb991481ba4c14622", null ],
    [ "rec_type", "group__devsup.html#gabe2c5ca7208f5ad5cfa396154bb509fe", null ],
    [ "rec_type_ptr", "group__devsup.html#ga2e1deb4e6755aa916fa748a3f9d7071c", null ],
    [ "report_type", "group__devsup.html#gaff59bad9e9023778f33885477242da1f", null ],
    [ "special_linconv_type", "group__devsup.html#ga04a86a79ca6602b78b89974891cad545", null ],
    [ "devTcDefIo", "group__devsup.html#gab816b7664be8e2e0dad6b086168c72b1", null ],
    [ "get_ioint_info_fn", "group__devsup.html#ga14bec2e66f2f2552fba6215c5ef70109", null ],
    [ "init_fn", "group__devsup.html#ga4b7d808b5d79ce7e736066de376497e7", null ],
    [ "init_record_fn", "group__devsup.html#gaab43aeb7333155db4b8b958fb763573b", null ],
    [ "io_fn", "group__devsup.html#ga1f21fd31fd4beccefc0cd021f68cf261", null ],
    [ "number", "group__devsup.html#gad97f59a982d7bb5504a7ea0659482a43", null ],
    [ "report_fn", "group__devsup.html#ga99a4aa74901147266ef3ccb98d3ccf1f", null ],
    [ "special_linconv_fn", "group__devsup.html#ga540ebb94e04c376bbb23f3576265eebc", null ]
];