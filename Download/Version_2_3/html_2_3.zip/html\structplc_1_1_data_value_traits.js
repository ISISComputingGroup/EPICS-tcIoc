var structplc_1_1_data_value_traits =
[
    [ "data_type_enum", "structplc_1_1_data_value_traits.html#ab020dda376e54142264e1603ff363765", null ],
    [ "size_type", "structplc_1_1_data_value_traits.html#a64953d6994fd793e4f1d9a662ac19edd", null ],
    [ "traits_atomic", "structplc_1_1_data_value_traits.html#acd4159349688d66b4cb220e4a62f0a86", null ],
    [ "traits_type", "structplc_1_1_data_value_traits.html#af85aee0d8389abcc790d056d97992891", null ]
];