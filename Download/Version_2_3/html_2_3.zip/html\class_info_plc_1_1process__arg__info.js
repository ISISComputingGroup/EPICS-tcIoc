var class_info_plc_1_1process__arg__info =
[
    [ "process_arg_info", "class_info_plc_1_1process__arg__info.html#a7f91717ee9a97f2458d6053579505413", null ],
    [ "get_full", "class_info_plc_1_1process__arg__info.html#a02e53c9d3389f6bd6594d78901f8e97b", null ],
    [ "tcplc_addr", "class_info_plc_1_1process__arg__info.html#a9caa0213eb47c90966fd8ba31ed5b07f", null ]
];