var struct_epics_tpy_1_1macro__record =
[
    [ "macro_record", "struct_epics_tpy_1_1macro__record.html#ad9fe58268902b9ca435ec21dda31515e", null ],
    [ "back", "struct_epics_tpy_1_1macro__record.html#a01989ecc19ffc212e2599e2e4452a0a7", null ],
    [ "erroridx", "struct_epics_tpy_1_1macro__record.html#aa2c90cdbf845ee1c00719a4a791c5c05", null ],
    [ "fields", "struct_epics_tpy_1_1macro__record.html#af2f8a7305b13cad6bc3c0c4c5e112481", null ],
    [ "haserror", "struct_epics_tpy_1_1macro__record.html#a59f92ef330f779ed3d2467ceeb1e9c8c", null ],
    [ "iserror", "struct_epics_tpy_1_1macro__record.html#a690d7dc2813183df90dc1153e2682a4c", null ],
    [ "record", "struct_epics_tpy_1_1macro__record.html#a14db1a021d87aa42949db59cdbc54aaf", null ]
];