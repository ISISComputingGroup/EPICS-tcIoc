var plc_base_template_8h =
[
    [ "reset_and_read", "plc_base_template_8h.html#a2243387df9aabe69528a8a5a1a6369aa", null ],
    [ "reset_and_read", "plc_base_template_8h.html#aa6d141a1e293fa86a1eec6f91dad2061", null ],
    [ "write_and_test", "plc_base_template_8h.html#ab846ebba1fce56e25aad68db393a7d9a", null ],
    [ "write_and_test", "plc_base_template_8h.html#a166d7d2ce9d3f07dd2c43c36cf0e5fba", null ]
];