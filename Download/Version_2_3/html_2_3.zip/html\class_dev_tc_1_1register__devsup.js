var class_dev_tc_1_1register__devsup =
[
    [ "link_func", "group__devsup.html#gab1a4f7ca2649b5db855260328ed5726d", null ],
    [ "test_pattern", "group__devsup.html#gab2b661a0e5aa45db9b32092b29fcaa42", null ],
    [ "test_pattern_list", "group__devsup.html#gad16b3191d143a7a48f53a90afd3057fa", null ],
    [ "register_devsup", "group__devsup.html#gaa9d299ba8b4d803d79f9770730e56081", null ],
    [ "register_devsup", "group__devsup.html#ga54d7aa20d1b083c6bfd8c426a5befbfd", null ],
    [ "register_devsup", "group__devsup.html#gaa37456634e65427b2f12a09d8b1a83f4", null ],
    [ "operator=", "group__devsup.html#ga1035e67515f9bedab988431392efdc03", null ],
    [ "operator=", "group__devsup.html#ga3acb3b330d0e1fce943db1d6ec9b21c0", null ],
    [ "tp_list", "group__devsup.html#gad0aa43e4d1130be653acb9766b3689c2", null ]
];