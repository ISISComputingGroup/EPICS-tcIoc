var struct_dev_tc_1_1dev_tc_def_out =
[
    [ "rec_type", "group__devsup.html#ga155da1f66b1772f23b82440a2897ca36", null ],
    [ "rec_type_ptr", "group__devsup.html#gaa389560e88619aa8d8258e304433aed8", null ],
    [ "devTcDefOut", "group__devsup.html#gaecacbc549f1ee8422b4881b400717b22", null ]
];