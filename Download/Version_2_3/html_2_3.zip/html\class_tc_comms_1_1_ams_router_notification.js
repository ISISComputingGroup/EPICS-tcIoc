var class_tc_comms_1_1_ams_router_notification =
[
    [ "get_ads_build", "class_tc_comms_1_1_ams_router_notification.html#aeda79eb3a769134eb0ccd7d57ddcc326", null ],
    [ "get_ads_revision", "class_tc_comms_1_1_ams_router_notification.html#ac48197ade3f04b5f8795e118e61b571f", null ],
    [ "get_ads_version", "class_tc_comms_1_1_ams_router_notification.html#a420cb812c6999c02cea92f2edc605895", null ],
    [ "RouterCall", "class_tc_comms_1_1_ams_router_notification.html#a608761250ae9f2b61b41bb60d7543d42", null ],
    [ "ads_build", "class_tc_comms_1_1_ams_router_notification.html#a6b83a5fad345d25d83630e830c42c7a4", null ],
    [ "ads_revision", "class_tc_comms_1_1_ams_router_notification.html#a31a3e213cea4d2fd7c23438b5b0cede3", null ],
    [ "ads_version", "class_tc_comms_1_1_ams_router_notification.html#aa17bd1d85a3ec6d0c484db9b3ef44851", null ]
];