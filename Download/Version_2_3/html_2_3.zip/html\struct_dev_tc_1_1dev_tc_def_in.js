var struct_dev_tc_1_1dev_tc_def_in =
[
    [ "rec_type", "group__devsup.html#gac99b578b92bef4b115f2282f4f5ab71d", null ],
    [ "rec_type_ptr", "group__devsup.html#ga0c0a615c66c632aa978c3388e940eb95", null ],
    [ "devTcDefIn", "group__devsup.html#ga1ebd175ad9de93c9c295677a2d99ab98", null ]
];